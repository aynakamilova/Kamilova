import os
import json

os.chdir('./')
options = '-nig --format json'
fsrc = '/Users/student/Desktop/KamilovaTest2/adyghe-unparsed-words.txt'
fout = '/Users/student/Desktop/KamilovaTest2/result.txt'

os.system(r"./mystem " + options + ' ' + fsrc + ' ' + fout)

nouns_file = open('rus_nouns.txt', 'w', encoding='utf-8')
finput = open(fout, 'r', encoding='utf-8')
for line in finput:
    result = json.loads(line.replace('\n', ' '))
    try:
        if result['analysis'][0].get('qual') == None and result['analysis'][0].get('gr') == 'S,имя,муж,од=им,ед':
            nouns_file.write(result['analysis'][0]['lex']+'\n')
    except:
        continue

finput.close()
nouns_file.close()
