from bs4 import BeautifulSoup

fhtml = open('/Users/student/Desktop/KamilovaTest2/ПОЛИТИКЭР _ Адыгэ Макъ.html', 'r', encoding='utf-8')
htmlsrc = fhtml.read()
fhtml.close()

bsObj = BeautifulSoup(htmlsrc, "lxml")
pubitems = bsObj.findAll("div", {"class":"box"})

corpus_set = set()

for item in pubitems:
    itemtext = item.get_text().lower()
    itemlst = itemtext.split()
    itemset = set(itemlst)
    corpus_set |= itemset


fwords = open('/Users/student/Desktop/KamilovaTest2/adyghe-unparsed-words.txt', 'r', encoding='utf-8')

wordsset = set()

for line in fwords:
    wordsset.add(line.replace('\n', ''))
fwords.close()


inter = wordsset & corpus_set

fout = open('wordlist.txt', 'w', encoding='utf-8')
for word in inter:
    fout.write(word+'\n')
fout.close()


