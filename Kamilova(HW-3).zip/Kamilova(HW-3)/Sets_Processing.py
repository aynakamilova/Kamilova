'''
Программа обработки текстов методами теории множеств.
Программа запускается ПОСЛЕ программы Yandex_Scrap и читает
заготовленные файлы src1 ... src6
В результате работы формируются файлы
intersection и symdif
'''

#Список будет хранить множества словоформ
#Одно множество в списке - одна статья
sets = []

# Обходим файлы статей, читаем
# Удаляем все лишнее, оставляем чистые словоформы
for i in range(1, 7):
    f = open('src' + str(i) +'.txt', 'r', encoding='utf-8')
    text = f.read()
    f.close()
    text = text.lower()
    text = text.replace('.', '')
    text = text.replace(',', '')
    text = text.replace('ё', 'е')
    text = text.replace('«', '')
    text = text.replace('»', '')
    text = text.replace('(', '')
    text = text.replace(')', '')
    text = text.replace('"', '')
    sets.append(set(text.split()))
# Все множества словоформ добавлены в список

# Получаем пересечение всех множеств
# То есть, общие словоформы всех статей
inter = sets[0] & sets[1] & sets[2] & sets[3] & sets[4] & sets[5]
interlst = list(inter)
f = open('intersection.txt', 'w', encoding='utf-8')
for word in sorted(interlst):
    f.write(word+'\n')
f.close()

# Получаем симметричную разность множеств
# То есть, словоформы, употребленные в разных статьях,
# но не являющиеся общими
# intersection + symdiff = это ВСЕ словоформы ВСЕХ статей
symdif = sets[0] ^ sets[1] ^ sets[2] ^ sets[3] ^ sets[4] ^ sets[5]
symdiflst = list(symdif)
f = open('symdiff.txt', 'w', encoding='utf-8')
for word in sorted(symdiflst):
    f.write(word+'\n')
f.close()

