'''
Скрапинг новостей Yandex
https://news.yandex.ru/yandsearch?lr=213&cl4url=lenta.ru%2Fnews%2F2016%2F11%2F30%2Ffight%2F&lang=ru&rubric=Moscow&from=index
Тема: Массовая драка на Черемушкинском рынке
Эта программа запускается первой, скачивает новости по ссылкам из заданных
источников.
Из-за блокировок со стороны Яндекса, ссылки на конкретные новости ввыбираются вручную
В результате работы создает файлы src1 - src6
После этого запускается программа Sets_Processing
'''
import urllib.request
from bs4 import BeautifulSoup
import re


regSpace = re.compile('\s{2,}', flags=re.U | re.DOTALL)
user_agent = 'Mozilla/5.0'

# #Новость на ленте ТАСС
url = 'http://tass.ru/proisshestviya/3825181'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src1.txt', 'w', encoding='utf-8')

h1 = bsObj.h1
f.write(h1.get_text()+'\n')


article = bsObj.find("div", {"class":"b-material-text__l js-mediator-article"})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub("", t)
    f.write(clean_t+'\n')

f.close()


#Новость на Эхе Москвы
url = 'http://echo.msk.ru/news/1883458-echo.html'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src2.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')

article = bsObj.find("div", {"class":"typical"})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()

# #Новость в Вечерней Москве
url = 'http://vm.ru/news/2016/11/30/vozbuzhdeno-ugolovnoe-delo-v-svyazi-s-potasovkoj-na-cheremushkinskom-rinke-341931.html'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src3.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')

article = bsObj.find('div', {'class':'s-article-content-block mrgbtm20'})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()

#Новость на Интерфаксе
url = 'http://www.interfax.ru/moscow/539179'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('cp1251')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src4.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')


article = bsObj.find("div", {"itemprop":"articleBody"})


for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()

#Новость на Life.Ru
url = 'https://life.ru/t/%D0%BD%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8/939020/svidietiel_pieriestrielki_na_chieriomushkinskom_rynkie_rasskazala_o_prichinakh_konflikta'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf-8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src5.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')


article = bsObj.find("div", {"itemprop":"text"})


for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()

#Новость За Калужской Заставой
url = 'http://gazetauzao.ru/massovaya-draka-na-cheremushkinskom-rynke-zakonchilas-strelboy-i-zaderzhaniem-direktora-vidyeo/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
req = urllib.request.Request(url, headers={'User-Agent':user_agent})
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf-8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('src6.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')

article = bsObj.find("div", {"itemprop":'articleBody'})


for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()
