import os
import json

mystemopts = '-cn --format json'
finput = 'InputText.txt'
foutput = 'Mystem.txt'

os.chdir('./')


os.system(r"./mystem " + mystemopts + ' ' + finput + ' ' + foutput)


tab2id = 0
tab1id = 0
ntok = 0



f = open(foutput, 'r', encoding='utf-8')
fsql = open('Output.sql', 'w')



lmark = ' '
rmark = ' '

'''Суть нижележащего цикла в следующем:
В выходном файле mystem есть строки двух типов
- где разбираются реальные словоформы (там есть атрибут analysis)
- где "разбираются" знаки препинания, в том числе - пробелы
Получив очередную строку и преобразовав к формату JSON,
пытаемся получить атирибут analysis. Если это получается, то
имеем словоформу и лемму, пишем в таблицу 2
Если не получается - имеем знак препинания.
Пишем таблицу 1, правый и левый знак, словоформу и лемму, которые мы запомнили
с предыдущей строки

'''

for line in f:
    jsonstr = json.loads(line.replace('\n', ' '))
    try:
        lemma = jsonstr['analysis'][0]['lex']
        token = jsonstr['text']
        tab2id += 10
        fsql.write('INSERT INTO table2 (id2, token, lemma) VALUES (' + str(tab2id) + ', "' + token.lower() + '", "' + lemma + '");\n')

    except:
        if token == ' ':
            continue
        tab1id += 1
        ntok += 1
        lmark = rmark
        rmark = jsonstr['text'].replace('\n', '')
        fsql.write('INSERT INTO table1 (id1, token, leftmark, rightmark, ntoken, id22) \
        VALUES ('
                   + str(tab1id) + ', ' +
                   '"' + token + '"' + ', ' +
                   '"' + lmark + '"' + ', ' +
                   '"' + rmark + '"' + ', ' +
                   str(ntok) + ', ' +
                   str(tab2id) +
                   ');\n')
        token = ' '


fsql.close()
f.close()


